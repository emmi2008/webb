/**
 * @author gp
 * @datetime 2012-9-17
 * @description index
 */

App.controller = Ambow.extend(App.TabList,{
	
	//模板文件名
	tplName:'tab2',
	
	//渲染页面
	render: function(){
		
	}
	
});
new App.controller();