/**
 * 
 */
 
 App.controller = Ambow.extend(App.Controller,{
	tplName:'highCharts',
	
	control: function(){}
	
	

});
new App.controller();